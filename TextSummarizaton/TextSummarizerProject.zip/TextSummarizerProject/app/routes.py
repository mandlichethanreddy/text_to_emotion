from flask import Flask, render_template, request
from app.summarizer import summarize_text

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    summary = ""
    original_text = ""
    if request.method == 'POST':
        original_text = request.form.get("text")
        if original_text:
            summary = summarize_text(original_text, num_sentences=3)
    return render_template('index.html', summary=summary, original_text=original_text)