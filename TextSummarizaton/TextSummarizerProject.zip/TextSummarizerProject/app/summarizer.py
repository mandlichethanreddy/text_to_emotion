import nltk
import os
from nltk.tokenize.punkt import PunktSentenceTokenizer, PunktParameters
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

# Add correct path manually if needed
nltk.data.path.append(r"C:\Users\hp\AppData\Roaming\nltk_data")

# Check and download punkt if missing
try:
    nltk.data.find("tokenizers/punkt")
except LookupError:
    nltk.download("punkt")

# ✅ Load correct tokenizer manually
tokenizer = PunktSentenceTokenizer()

def summarize_text(text, num_sentences=3):
    sentences = tokenizer.tokenize(text)

    if len(sentences) <= num_sentences:
        return text

    tfidf = TfidfVectorizer().fit_transform(sentences)
    similarity_matrix = cosine_similarity(tfidf)
    scores = similarity_matrix.sum(axis=1)
    ranked_sentences = [sentences[i] for i in np.argsort(scores)[::-1][:num_sentences]]
    return ' '.join(ranked_sentences)